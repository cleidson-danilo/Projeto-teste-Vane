var express = require('express');

const app = express();

app.get("/", function(req, res){
    res.sendFile(__dirname + "/src/teste.html")
});
app.get("/sobre", function(req, res){
    res.send("pagina sobre");
});
app.get("/produto", function(req, res){
    res.send("produto");
});
app.get("/contato", function(req, res){
    res.send("contato teste");
});
app.get("/faleconosco", function(req, res){
    res.send("fale conosco");
});




app.listen(5500);
console.log("Servidor Rodando na url http://localhost:5500")