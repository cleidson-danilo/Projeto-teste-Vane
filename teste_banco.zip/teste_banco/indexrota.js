var express = require('express');

const app = express();

app.get("/", function(req, res){
    res.send("Gerenciador Financeiro")
});
app.get("/sobre-empresa", function(req, res){
    res.send("pagina sobre a empresa");
});
app.get("/blog", function(req, res){
    res.send("blog da empresa");
});
app.get("/contato", function(req, res){
    res.send("contato da empresa");
});


app.listen(5500);
console.log("Servidor Rodando na url http://localhost:5500")