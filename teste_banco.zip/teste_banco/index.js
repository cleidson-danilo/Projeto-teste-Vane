var express = require('express');

const app = express();

app.get("/", function(req, res){
    res.send("Gerenciador Financeiro")
})


app.listen(5500);
console.log(" Servidor Rodando na url http://localhost:5500")